// KISI 3: Round Robin burada yazilacak. Simdilik bos iskelet.
#include "scheduler.h"
SchedulingResult runRoundRobin(std::vector<Process> procs, int quantum) {
    (void)procs; (void)quantum;
    SchedulingResult res;
    res.algorithm = "Round Robin";
    return res;
}
